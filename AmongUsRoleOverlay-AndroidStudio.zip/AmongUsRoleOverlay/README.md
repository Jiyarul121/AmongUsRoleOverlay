# Among Us Role Overlay (Android)

A native Android floating-window shell with a local HTML role tracker. Players and roles are entered manually. The app does not inspect Among Us memory, network traffic, screen contents, or hidden game state.

## Features
- Android system overlay permission and draggable floating panel
- Add/remove player names or colours
- Assign a role manually, mark alive/dead, add notes
- Filter by Crewmate, Impostor, Ghost; search players
- Local device save using WebView storage; JSON export
- Stop the overlay from the launcher activity or swipe the top bar right

## Included role list
Crewmate, Scientist, Engineer, Noisemaker, Tracker, Detective, Judge, Guardian Angel, Influencer, Impostor, Shapeshifter, Phantom, Viper. Guardian Angel and Influencer are grouped under Ghost in the tracker. Role descriptions are short summaries, not full game instructions.

## Build an APK
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support).
2. Allow Gradle sync to download the Android Gradle Plugin and SDK 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated debug APK on your Android phone.
5. Open the app, tap **Allow display over other apps**, enable permission, return, then tap **Start floating role menu**.
6. Open Among Us. The overlay stays above other apps until closed or stopped.

Min Android version: Android 8.0 (API 26). The project targets API 35. Android may ask for notification permission on newer versions. The foreground notification indicates the overlay is running.

## Important
- This is a source project, not a prebuilt/signed APK. Build it in Android Studio.
- The supplied `AmongUsOffsetsDumper.exe` is a Windows x64 executable. It is not required by this project and no offsets from it are used.
- Role list reflects official Among Us releases reported through mobile v19.0.1 (Nov 2026). Check the official update notes for future changes.
