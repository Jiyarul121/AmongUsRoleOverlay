package com.example.amongusroleoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "Among Us Role Overlay\n\nManual role tracker for the latest Among Us role set. It does not read game data or reveal hidden roles."
            textSize = 18f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val permission = Button(this).apply { text = "1. Allow display over other apps"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } }
        layout.addView(permission, LinearLayout.LayoutParams(-1, -2))
        val start = Button(this).apply { text = "2. Start floating role menu"; setOnClickListener {
            if (Settings.canDrawOverlays(this@MainActivity)) {
                val i = Intent(this@MainActivity, OverlayService::class.java)
                startForegroundService(i)
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        } }
        layout.addView(start, LinearLayout.LayoutParams(-1, -2))
        val stop = Button(this).apply { text = "Stop overlay"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } }
        layout.addView(stop, LinearLayout.LayoutParams(-1, -2))
        setContentView(layout)
    }
}
