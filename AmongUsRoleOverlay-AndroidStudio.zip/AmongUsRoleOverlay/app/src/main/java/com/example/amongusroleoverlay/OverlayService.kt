package com.example.amongusroleoverlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.webkit.WebView
import android.webkit.WebViewClient

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private val channelId = "role_overlay"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId).setContentTitle("Role overlay is running")
                .setContentText("Tap to return to the role tracker")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true).build()
        } else Notification.Builder(this).setContentTitle("Role overlay is running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        startForeground(7, notification)
        showOverlay()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(channelId, "Role overlay", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = TextView(this).apply {
            text = "☰  AMONG US ROLE TRACKER     ×"
            textSize = 14f; setTextColor(0xffffffff.toInt()); setBackgroundColor(0xff252b43.toInt())
            setPadding(14, 12, 14, 12)
        }
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            setBackgroundColor(0xff101525.toInt())
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            (resources.displayMetrics.heightPixels * 0.72).toInt(),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 70 }
        bar.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ix = 0; var iy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ix=params.x; iy=params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x=ix+(e.rawX-sx).toInt(); params.y=iy+(e.rawY-sy).toInt(); windowManager.updateViewLayout(root, params); return true }
                    MotionEvent.ACTION_UP -> if (e.rawX - sx > 120) { stopSelf(); return true }
                }
                return true
            }
        })
        overlay = root
        windowManager.addView(root, params)
    }

    override fun onDestroy() { if (overlay != null) { windowManager.removeView(overlay); overlay = null }; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
